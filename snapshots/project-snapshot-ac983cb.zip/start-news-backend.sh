#!/bin/bash
export ALPHA_VANTAGE_API_KEY=M768ALQQ3JVUXCGC
cd /workspaces/2025-10-29_Frontend-scomposto-funzionante-v1/backend/backend-news
echo "🚀 Avvio backend news con API key: M768ALQQ3JVUXCGC"
python app.py